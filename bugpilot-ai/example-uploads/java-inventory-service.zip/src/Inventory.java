import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private final List<String> items = new ArrayList<>();
    public String get(int index) { return items.get(index); }
    public void add(String item) { items.add(item); }
    public void remove(int index) { items.remove(index); }
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        inventory.add(args[0]);
        System.out.println(inventory.get(Integer.parseInt(args[1])));
    }
}
