# Java Inventory Service
A minimal inventory service with unsafe index access and no input checks.
