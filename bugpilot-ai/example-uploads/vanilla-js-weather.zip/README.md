# Vanilla JS Weather Widget
A small weather widget with request, rendering, and loading-state bugs to investigate.
