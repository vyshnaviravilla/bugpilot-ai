const button = document.querySelector('#load');
const status = document.querySelector('#status');
const list = document.querySelector('#forecast');
button.addEventListener('click', async () => {
  status.textContent = 'Loading?';
  const city = document.querySelector('#city').value;
  const response = await fetch(`/api/weather?city=${city}`);
  const data = await response.json();
  list.innerHTML = data.days.map(day => `<li>${day.date}: ${day.temperature}</li>`).join('');
});
