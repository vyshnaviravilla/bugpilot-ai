import { useState } from 'react';

export default function App() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState('');
  function addTodo() {
    todos.push({ id: Date.now(), text });
    setTodos(todos);
    setText('');
  }
  return <main><input value={text} onChange={e => setText(e.target.value)} />
    <button onClick={addTodo}>Add</button>
    {todos.map(todo => <p key={todo.text}>{todo.text}</p>)}
  </main>;
}
