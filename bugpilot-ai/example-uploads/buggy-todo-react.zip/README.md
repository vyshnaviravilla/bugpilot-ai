# Buggy Todo React
A small React todo app with intentional state and rendering issues for upload analysis.
