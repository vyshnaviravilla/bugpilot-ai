# Node Store API
A tiny Express store API with intentionally unsafe validation and error handling.
