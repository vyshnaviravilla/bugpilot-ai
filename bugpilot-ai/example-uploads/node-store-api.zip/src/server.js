const express = require('express');
const app = express();
app.use(express.json());
const products = [];
app.get('/products', (req, res) => res.json(products));
app.get('/products/:id', (req, res) => res.json(products[req.params.id]));
app.post('/products', (req, res) => {
  products.push(req.body);
  res.status(201).json(products[products.length - 1]);
});
app.delete('/products/:id', (req, res) => {
  products.splice(req.params.id, 1);
  res.sendStatus(204);
});
app.listen(3000);
