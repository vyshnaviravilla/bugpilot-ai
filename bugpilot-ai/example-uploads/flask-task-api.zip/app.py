from flask import Flask, request, jsonify
app = Flask(__name__)
tasks = []
@app.get('/tasks/<int:task_id>')
def get_task(task_id):
    return jsonify(tasks[task_id])
@app.post('/tasks')
def create_task():
    task = request.json
    tasks.append(task)
    return jsonify(task), 201
@app.delete('/tasks/<int:task_id>')
def delete_task(task_id):
    tasks.pop(task_id)
    return '', 204
if __name__ == '__main__':
    app.run(debug=True)
