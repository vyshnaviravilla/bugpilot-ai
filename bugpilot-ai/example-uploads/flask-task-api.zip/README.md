# Flask Task API
A tiny task service with missing validation and fragile lookup behavior.
