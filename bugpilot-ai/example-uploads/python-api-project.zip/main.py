from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI()

# BUG 1: Using mutable default argument
class Item(BaseModel):
    name: str
    price: float
    tags: List[str] = []  # Mutable default - shared across instances

# In-memory storage
items_db = {}

# BUG 2: SQL injection vulnerability (simulated)
def get_item_query(item_id: str) -> str:
    return f"SELECT * FROM items WHERE id = {item_id}"  # Unsafe string formatting

# BUG 3: Missing error handling
@app.get("/items/{item_id}")
async def get_item(item_id: str):
    item = items_db.get(item_id)
    return item  # Returns None if not found instead of 404

# BUG 4: Race condition in item creation
@app.post("/items")
async def create_item(item: Item):
    if item.name in items_db:
        return {"error": "Item exists"}  # Not atomic check-then-act
    items_db[item.name] = item
    return item

# BUG 5: No input validation
@app.get("/search")
async def search_items(query: str):
    results = []
    for item in items_db.values():
        if query in item.name:  # No sanitization of query
            results.append(item)
    return results

# BUG 6: Unbounded list processing
@app.get("/items/all")
async def get_all_items():
    return list(items_db.values())  # Could be huge, no pagination

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
