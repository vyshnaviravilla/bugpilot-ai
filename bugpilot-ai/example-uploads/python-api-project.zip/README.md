# Python API Project - Example Project

A simple FastAPI application with intentional security and logic bugs for testing BugPilot AI.

## Known Bugs

1. **Mutable default argument** (line 7)
   - `tags: List[str] = []` is shared across all instances
   - Should use `tags: Optional[List[str]] = None` and handle in __init__

2. **SQL injection vulnerability** (lines 11-13)
   - String formatting in SQL query is unsafe
   - Should use parameterized queries

3. **Missing error handling** (lines 18-21)
   - Returns None instead of HTTP 404 when item not found
   - Should check if item exists and raise HTTPException

4. **Race condition** (lines 24-29)
   - Check-then-act pattern is not atomic
   - Could lead to duplicate items in concurrent requests

5. **No input validation** (lines 32-37)
   - Search query is not sanitized
   - Could lead to performance issues or unexpected behavior

6. **Unbounded list processing** (lines 40-43)
   - Returns all items without pagination
   - Could cause memory issues with large datasets

## Setup

```bash
pip install -r requirements.txt
python main.py
```

## Testing

Use this project to test:
- Security vulnerability detection
- API endpoint analysis
- Code quality checks
