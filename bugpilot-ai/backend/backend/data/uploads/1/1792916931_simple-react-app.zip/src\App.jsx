import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [count, setCount] = useState(0);
  const [items, setItems] = useState([]);
  
  // BUG 1: Missing dependency array in useEffect
  useEffect(() => {
    console.log('Component mounted');
  });

  // BUG 2: Async function without error handling
  const fetchData = async () => {
    const response = await fetch('/api/items');
    const data = await response.json();
    setItems(data);
  };

  // BUG 3: Division by zero potential
  const calculateAverage = (numbers) => {
    const sum = numbers.reduce((a, b) => a + b, 0);
    return sum / numbers.length; // Will crash if numbers is empty
  };

  // BUG 4: Memory leak - setState on unmounted component
  useEffect(() => {
    const interval = setInterval(() => {
      setCount(prev => prev + 1);
    }, 1000);
    // Missing cleanup function
  }, []);

  return (
    <div className="App">
      <h1>Simple React App</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={fetchData}>Fetch Data</button>
      <div>
        <h3>Items:</h3>
        {items.map(item => (
          <div key={item.id}>{item.name}</div>
        ))}
      </div>
    </div>
  );
}

export default App;
