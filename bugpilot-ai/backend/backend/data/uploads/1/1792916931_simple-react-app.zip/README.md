# Simple React App - Example Project

This is a minimal React application with intentional bugs for testing BugPilot AI's bug detection capabilities.

## Known Bugs

1. **Missing dependency array in useEffect** (line 8-11)
   - The useEffect runs on every render instead of only on mount
   - Should have an empty dependency array: `useEffect(() => {}, [])`

2. **No error handling in async function** (line 14-18)
   - fetchData() doesn't handle network errors or invalid responses
   - Should include try-catch block

3. **Division by zero** (line 21-24)
   - calculateAverage() will crash if the numbers array is empty
   - Should check if array is empty before division

4. **Memory leak in interval** (line 27-32)
   - setInterval is not cleaned up when component unmounts
   - Should return a cleanup function: `return () => clearInterval(interval)`

## Setup

```bash
npm install
npm start
```

## Testing

Use this project to test:
- Bug detection algorithms
- Code analysis features
- Report generation
